

let gainer: any[] = []; 

export default gainer;
