

let loser: any[] = []; 

export default loser;
