import Negative1 from "./Negative1.png"
import Negative2 from "./Negative2.png"
import Positive1 from "./Positive1.png"
import Positive2 from "./Positive2.png"
import Positive3 from "./Positive3.png"
import Positive4 from "./Positive4.png"
import Negative3 from "./Negative3.png"
import Negative4 from "./Negative4.png"

export{
    Negative1,
    Negative2,
    Positive1,
    Positive2,
    Positive3,
    Positive4,
    Negative3,
    Negative4

}